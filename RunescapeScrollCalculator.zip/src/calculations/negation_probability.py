
def negation_scroll_cost_probability(scrolls_needed, scroll_probability, cost_per_scroll):
    iterations = 1
    current_chance = (1 - scroll_probability)
    while current_chance > .05:
        current_chance *= (1 - scroll_probability)
        iterations += 1

    return (iterations, iterations * cost_per_scroll)