from datetime import datetime

from .jobs.store_jar_value import store_jar_api_data
from .jobs.store_casket_api_data import store_casket_api_data
from .jobs.store_scroll_chance import store_scroll_chance_api_data
from .spreadsheeting.create_scroll_chances import create_scroll_spreadsheet

def main():
    now = int(datetime.now().timestamp())
    store_jar_api_data(now)
    store_casket_api_data(now)
    store_scroll_chance_api_data(now)
    create_scroll_spreadsheet()

if __name__ == "__main__":
    main()