# Runescape Scroll Calculator

## Directory Structure
```
. [INSTALL_DIRECTORY]
├── casket_values.json
├── Clue Scroll Costs.xlsm
├── clue_scroll.xlsm
├── example.png
├── impling_values.json
├── jar_values.json
├── lootitem_values.json
├── readme.md
├── requirements.txt
└── src
    ├── calculations
    │   ├── calculation_strategies.py
    │   ├── naive.py
    │   └──  negation_probability.py
    ├── config
    │   └── config.py
    ├── data
    │   ├── caskets.py
    │   ├── casket_storage.py
    │   ├── implings.py
    │   ├── impling_storage.py
    │   ├── jar_storage.py
    │   ├── loot_items.py
    │   ├── lootitem_storage.py
    │   └── scrolls.py
    ├── helpers
    │   └── helpers.py
    ├── jobs
    │   ├── retrieve_casket_value.py
    │   ├── retrieve_impling_value.py
    │   ├── retrieve_jar_value.py
    │   ├── retrieve_lootitem_value.py
    │   ├── store_casket_api_data.py
    │   ├── store_impling_api_data.py
    │   ├── store_jar_value.py
    │   └── store_lootitem_api_data.py
    ├── main.py
    └── spreadsheeting
        ├── create_impling_value_spreadsheet.py
        ├── create_lootitem_value_spreadsheet.py
        ├── create_scroll_chances.py
        └── __init__.py    
```

## Install Requirements
`pip3 install -r requirements.txt`

Extract to `[INSTAL_DIRECTORY]`

## Running
```
cd [INSTALL_DIRECTORY]
python -m src.main
```

This builds a spreadsheet in `[INSTALL_DIRECTORY]` called `clue_scroll.xlsm`. This is where all the data gets viewed. After its generated, you can style how you choose, save it, and those formatting things will carry over. To grab new data, rerun the program and reopen the spreadsheet.

There are 3 sheets in total - `IMPLINGS`, `LOOT_ITEMS`, and `SCROLLS` (LOOT_ITEMS can be ignored now, I'm pulling the expected loot from the jar table on the wiki now). The first two are for viewing the Graph and Grand Exchange data. `SCROLLS` is as below:

![example.png](example.png)